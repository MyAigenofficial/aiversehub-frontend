
from flask import Flask, request, jsonify
app = Flask(__name__)

@app.route('/')
def home():
    return "AIVerseHub Backend Running"

@app.route('/slideshow-video', methods=['POST'])
def slide():
    return jsonify({"status":"ok","message":"Slideshow video generated"})

@app.route('/avatar-video', methods=['POST'])
def avatar():
    return jsonify({"status":"ok","message":"Avatar video generated"})

@app.route('/text-audio', methods=['POST'])
def audio():
    return jsonify({"status":"ok","message":"Audio generated"})

@app.route('/voice-clone', methods=['POST'])
def clone():
    return jsonify({"status":"ok","message":"Voice cloned"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
